@echo off
echo Setting up Hop6 Engine...
if not exist venv (
    python -m venv venv
)
call venv\Scripts\activate
pip install -r requirements.txt
python cli.py
pause
