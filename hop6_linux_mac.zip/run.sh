#!/bin/bash
echo "Setting up Hop6 Engine..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt
python cli.py
