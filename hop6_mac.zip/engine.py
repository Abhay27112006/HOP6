"""
Hop6 Engine — Core library for the Hop6 Architecture.

Two modes of operation:
  1. Static Extraction: Extract 6 layers permanently (for portable models).
  2. Dijkstra Dynamic Routing: Keep all layers, route each token through 6 hops at runtime.

Both modes use Dynamic VRAM Paging — only 1 layer in GPU memory at a time.
"""

import os
import json
import random
import networkx as nx
import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer


# ============================================================
# Graph Construction (shared by both modes)
# ============================================================

def build_layer_graph(num_layers, wormhole_pct=0.30):
    """
    Creates a directed graph where nodes are layers.
    Sequential edges: i -> i+1
    Wormhole edges:   30% extra random skip connections (jump >= 2 layers).
    """
    G = nx.DiGraph()
    edges = []

    for i in range(num_layers):
        G.add_node(i)
        if i < num_layers - 1:
            G.add_edge(i, i + 1)
            edges.append((i, i + 1))

    num_wormholes = int(num_layers * wormhole_pct)
    added = 0
    while added < num_wormholes:
        src = random.randint(0, num_layers - 3)
        dst = random.randint(src + 2, num_layers - 1)
        if not G.has_edge(src, dst):
            G.add_edge(src, dst)
            edges.append((src, dst))
            added += 1

    return G, edges


def find_hop_path(G, source, target, max_hops=6):
    """Find the best path from source to target within max_hops."""
    try:
        paths = list(nx.all_simple_paths(G, source=source, target=target, cutoff=max_hops))
        if not paths:
            raise ValueError("No path found")
        paths.sort(key=lambda p: abs(len(p) - max_hops))
        return paths[0]
    except Exception:
        return torch.linspace(source, target, max_hops).long().tolist()


# ============================================================
# Mode 1: Static Extraction (convert & save a 6-layer model)
# ============================================================

def convert_to_hop6(model_id, save_dir, max_hops=6):
    """
    Loads a pretrained model, constructs the small-world graph,
    finds the 6-hop path, extracts those layers, and saves permanently.
    """
    print(f"[Hop6] Loading {model_id}...")
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id, torch_dtype=torch.float16, device_map="cpu", trust_remote_code=True
    )

    if not hasattr(model, "model") or not hasattr(model.model, "layers"):
        raise ValueError("Model not supported. Must have model.model.layers.")

    num_layers = len(model.model.layers)
    print(f"[Hop6] Base model depth: {num_layers} layers.")

    G, _ = build_layer_graph(num_layers)
    path = find_hop_path(G, source=0, target=num_layers - 1, max_hops=max_hops)
    print(f"[Hop6] Traversed Path: {path}")
    print(f"[Hop6] Executing {len(path)} layers total.")

    # Extract layers
    model.model.layers = nn.ModuleList([model.model.layers[i] for i in path])
    model.config.num_hidden_layers = len(path)
    if hasattr(model.config, "layer_types") and isinstance(model.config.layer_types, list):
        model.config.layer_types = [model.config.layer_types[i] for i in path]

    # Save
    os.makedirs(save_dir, exist_ok=True)
    print(f"[Hop6] Saving to {save_dir}...")
    try:
        model.save_pretrained(save_dir)
        tokenizer.save_pretrained(save_dir)
    except Exception as e:
        print(f"[Hop6] HF save failed ({e}), falling back to torch.save...")
        torch.save(model.state_dict(), os.path.join(save_dir, "model.pt"))
        tokenizer.save_pretrained(save_dir)
        try:
            model.config.save_pretrained(save_dir)
        except Exception:
            pass

    meta = {
        "architecture": "Hop6",
        "original_model": model_id,
        "original_depth": num_layers,
        "hop_path": path,
        "wormhole_pct": 0.30,
    }
    with open(os.path.join(save_dir, "hop6_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print("[Hop6] Conversion complete!")


# ============================================================
# Mode 2: Dijkstra Dynamic Routing (keep ALL layers, route at runtime)
# ============================================================

class TokenRouter(nn.Module):
    """
    Tiny neural network (< 5 MB) that lives permanently in VRAM.
    Takes a token embedding and predicts edge costs for Dijkstra.
    """
    def __init__(self, hidden_dim, num_edges):
        super().__init__()
        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 4),
            nn.ReLU(),
            nn.Linear(hidden_dim // 4, num_edges),
            nn.Softplus(),  # costs must be > 0 for Dijkstra
        )

    def forward(self, x):
        return self.predictor(x)


class BridgeNetwork(nn.Module):
    """
    Small network (~5-20M params) that stays permanently in VRAM.
    Transforms hidden states across layer gaps to fix the distribution
    mismatch caused by skipping layers.

    Given the output of layer `src`, produces an approximation of what
    layer `dst - 1` would have outputted, so layer `dst` receives the
    input distribution it was trained to expect.

    Uses a gated residual: output = h + sigmoid(gate) * delta
    Gate starts at 0 (identity), so the bridge can never make things
    worse than the current system before training.
    """
    def __init__(self, hidden_dim, num_layers, bottleneck_ratio=4):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        # Layer index embeddings — let the bridge know which layers it's bridging
        layer_embed_dim = hidden_dim // 8
        self.layer_embed = nn.Embedding(num_layers, layer_embed_dim)

        # MLP: takes [hidden_states, src_embed, dst_embed] → delta correction
        input_dim = hidden_dim + 2 * layer_embed_dim
        mid_dim = hidden_dim // bottleneck_ratio
        self.net = nn.Sequential(
            nn.Linear(input_dim, mid_dim),
            nn.GELU(),
            nn.Linear(mid_dim, mid_dim),
            nn.GELU(),
            nn.Linear(mid_dim, hidden_dim),
        )

        # Learnable gate — starts at 0 so bridge begins as identity (safe)
        self.gate = nn.Parameter(torch.zeros(1))

    def forward(self, h, src_idx, dst_idx):
        """
        Args:
            h: hidden states from source layer, shape (batch, seq_len, hidden_dim)
            src_idx: source layer index (int)
            dst_idx: destination layer index (int)
        Returns:
            Adjusted hidden states approximating layer[dst-1]'s output.
        """
        device = h.device
        batch, seq_len, _ = h.shape

        # Get layer embeddings and broadcast to (batch, seq_len, embed_dim)
        src_e = self.layer_embed(torch.tensor(src_idx, device=device))
        dst_e = self.layer_embed(torch.tensor(dst_idx, device=device))
        src_e = src_e.unsqueeze(0).unsqueeze(0).expand(batch, seq_len, -1)
        dst_e = dst_e.unsqueeze(0).unsqueeze(0).expand(batch, seq_len, -1)

        # Concatenate and predict correction
        x = torch.cat([h, src_e, dst_e], dim=-1)
        delta = self.net(x)

        # Gated residual — gate starts at 0 (identity), learns to open
        return h + torch.sigmoid(self.gate) * delta


class Hop6DijkstraEngine(nn.Module):
    """
    Wraps any HuggingFace causal-LM model.
    All layers stay in System RAM.  For each forward pass the TokenRouter
    predicts edge costs, Dijkstra finds the cheapest ≤6-hop path, and only
    those layers are paged into VRAM one at a time.

    The BridgeNetwork fixes hidden-state distribution mismatch when skipping
    layers via wormholes.  It runs automatically on any jump where gap > 1.
    """

    def __init__(self, model, wormhole_pct=0.30, max_hops=6, target_device="cuda"):
        super().__init__()
        self.target_device = target_device
        self.model = model
        self.max_hops = max_hops
        self.layers = self.model.model.layers
        self.num_layers = len(self.layers)

        # Keep every layer on CPU
        for layer in self.layers:
            layer.to("cpu")

        # Build graph
        self.graph, self.edges = build_layer_graph(self.num_layers, wormhole_pct)

        # Router lives permanently in VRAM
        hidden_dim = self.model.config.hidden_size
        self.router = TokenRouter(hidden_dim, len(self.edges)).to(self.target_device).to(model.dtype)

        # Bridge Network lives permanently in VRAM (~10-40 MB)
        self.bridge = BridgeNetwork(hidden_dim, self.num_layers).to(self.target_device).to(model.dtype)

        # Embeddings + LM head stay in VRAM permanently (small)
        self.model.model.embed_tokens.to(self.target_device)
        if hasattr(self.model.model, "norm"):
            self.model.model.norm.to(self.target_device)
        if hasattr(self.model, "lm_head"):
            self.model.lm_head.to(self.target_device)

        bridge_params = sum(p.numel() for p in self.bridge.parameters())
        print(f"[Hop6 Dijkstra] Graph: {self.num_layers} nodes, {len(self.edges)} edges "
              f"(+{int(self.num_layers * wormhole_pct)} wormholes). Max hops: {max_hops}.")
        print(f"[Hop6 Bridge] {bridge_params/1e3:.1f}K params "
              f"({bridge_params * 2 / 1024 / 1024:.1f} MB fp16) — fixes distribution mismatch.")
        self.config = self.model.config
        
        # State for Per-Sequence Routing
        self.current_path = None

    # ---- layer paging ------------------------------------------------
    def _page_execute(self, layer_idx, hidden_states, prev_layer_idx=None,
                      attention_mask=None, position_ids=None,
                      past_key_value=None, use_cache=False):
        """
        Page a single layer into VRAM, execute it, and evict it back to CPU.
        If prev_layer_idx is given and the gap is > 1 (wormhole jump),
        the BridgeNetwork is applied first to fix the distribution mismatch.
        """
        # Apply bridge on wormhole jumps (gap > 1 layer)
        if prev_layer_idx is not None and (layer_idx - prev_layer_idx) > 1:
            hidden_states = self.bridge(hidden_states, prev_layer_idx, layer_idx)

        layer = self.layers[layer_idx]
        layer.to(self.target_device)

        # Synchronize before compute to ensure transfer is complete
        if self.target_device != "cpu" and torch.cuda.is_available():
            torch.cuda.synchronize()

        # Handle different HF cache formats (Cache object vs tuple)
        kwargs = {"use_cache": use_cache}
        if past_key_value is not None:
            kwargs["past_key_value"] = past_key_value

        out = layer(hidden_states, attention_mask=attention_mask,
                    position_ids=position_ids, **kwargs)

        # Synchronize before eviction to avoid data races
        if self.target_device != "cpu" and torch.cuda.is_available():
            torch.cuda.synchronize()

        layer.to("cpu")

        # Free VRAM immediately so next layer has room
        if self.target_device != "cpu" and torch.cuda.is_available():
            torch.cuda.empty_cache()

        return out

    # ---- forward with dynamic routing --------------------------------
    def forward(self, input_ids=None, attention_mask=None, position_ids=None, past_key_values=None, use_cache=None, **kwargs):
        # Handle fallback for use_cache
        if use_cache is None:
            use_cache = self.config.use_cache if hasattr(self.config, "use_cache") else False

        hidden_states = self.model.model.embed_tokens(input_ids.to(self.target_device))

        # Per-Sequence Routing: Compute path only if past_key_values is None (prefill phase)
        if past_key_values is None:
            # Route based on last token of the prompt
            last_tok = hidden_states[:, -1, :]
            costs = self.router(last_tok)[0].detach().cpu().numpy()

            for idx, (u, v) in enumerate(self.edges):
                self.graph[u][v]["weight"] = costs[idx].item()

            try:
                path = nx.shortest_path(self.graph, source=0,
                                        target=self.num_layers - 1, weight="weight")
                if len(path) > self.max_hops:
                    path = path[: self.max_hops - 1] + [self.num_layers - 1]
            except nx.NetworkXNoPath:
                path = [0, self.num_layers - 1]
                
            self.current_path = path
            print(f" [route prefill: {path}]", end="", flush=True)
        else:
            path = self.current_path

        if not hasattr(self, 'current_step'):
            self.current_step = 0
            
        print(f"step {self.current_step}: path = {path}")
        self.current_step += 1

        # Execute layers with bridge on wormhole jumps and handle KV cache
        prev_idx = None
        next_decoder_cache = () if use_cache else None
        
        # Determine if past_key_values is a new Cache object or old tuple format
        is_cache_object = past_key_values is not None and not isinstance(past_key_values, tuple)

        for i, layer_idx in enumerate(path):
            # Extract layer-specific past_key_value
            layer_past = None
            if past_key_values is not None:
                if is_cache_object:
                    # For newer HF models using Cache objects (DynamicCache), 
                    # we often pass the whole cache and the layer uses its index.
                    # Or we just pass the cache and let the layer handle it.
                    layer_past = past_key_values
                else:
                    # Old tuple format: we only stored cache for the layers we executed
                    # length of past_key_values matches length of path
                    if i < len(past_key_values):
                        layer_past = past_key_values[i]

            out = self._page_execute(
                layer_idx, hidden_states, prev_layer_idx=prev_idx,
                attention_mask=attention_mask, position_ids=position_ids,
                past_key_value=layer_past, use_cache=use_cache
            )
            hidden_states = out[0]
            
            if use_cache:
                if is_cache_object:
                    # The Cache object updates in place
                    next_decoder_cache = out[1] if len(out) > 1 else past_key_values
                else:
                    # Append the layer's KV cache to the tuple
                    if len(out) > 1:
                        next_decoder_cache += (out[1],)
                        
            prev_idx = layer_idx

        if hasattr(self.model.model, "norm"):
            hidden_states = self.model.model.norm(hidden_states)

        logits = self.model.lm_head(hidden_states)

        from transformers.modeling_outputs import CausalLMOutputWithPast
        return CausalLMOutputWithPast(
            logits=logits,
            past_key_values=next_decoder_cache
        )

    # ---- HF generate compatibility -----------------------------------
    def generate(self, *args, **kwargs):
        self.current_path = None  # Reset path for new generation
        self.current_step = 0
        return self.model.generate(*args, **kwargs)

    def prepare_inputs_for_generation(self, *args, **kwargs):
        return self.model.prepare_inputs_for_generation(*args, **kwargs)

    def _update_model_kwargs_for_generation(self, *args, **kwargs):
        return self.model._update_model_kwargs_for_generation(*args, **kwargs)

    @property
    def main_input_name(self):
        return self.model.main_input_name

    @property
    def device(self):
        return torch.device(self.target_device)


# ============================================================
# Paged loader (for pre-extracted Hop6 models)
# ============================================================

class PagedLayer(nn.Module):
    """Wraps a single transformer layer for dynamic VRAM paging."""
    def __init__(self, layer, device="cuda"):
        super().__init__()
        self.layer = layer.to("cpu")
        self.target_device = device

    def forward(self, *args, **kwargs):
        self.layer.to(self.target_device)
        gpu_args = [a.to(self.target_device) if isinstance(a, torch.Tensor) else a for a in args]
        gpu_kwargs = {k: (v.to(self.target_device) if isinstance(v, torch.Tensor) else v)
                      for k, v in kwargs.items()}
        out = self.layer(*gpu_args, **gpu_kwargs)
        self.layer.to("cpu")
        return out


def load_hop6(local_path, device="cuda"):
    """Load a pre-extracted Hop6 model and wrap layers for paging."""
    tokenizer = AutoTokenizer.from_pretrained(local_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        local_path, torch_dtype=torch.float16, device_map="cpu", trust_remote_code=True
    )
    paged = nn.ModuleList([PagedLayer(l, device) for l in model.model.layers])
    model.model.layers = nn.ModuleList()
    model.to(device)
    model.model.layers = paged
    return model, tokenizer
